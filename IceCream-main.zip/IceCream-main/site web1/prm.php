<?php include "include/fonctions.php";
       $pagetitre= 'promotions';
        ?> 

<!DOCTYPE html> 
<html>
    <head> 
	   <title><?php getTitle()?></title>
	   <link rel="stylesheet" href="themes/style-menu.css"> 
       <link rel="stylesheet" href="themes/style.css">
       <link rel="stylesheet" href="themes/style-menu.css">
	</head>
	
	<body> 
        <nav class="navbar">
            <div class="max-width">
                <div class="logo"><a href="#">  Ice<span>Cream.</span></a></div>
                 <ul class="menu">
                   <li><a href="#">our concept</a></li>
                     <li><a href="menu.php">menu</a></li>
                     <li><a href="prm.php">promotions</a></li>
                     
                     <li><a  href="#"><span>order online </span></a></li>
                 </ul>
                 
                 <div class=menu-btn>
                     <i class="fas fa-bars"></i>
                 </div> 
            </div>
       </nav>
		<header>
            
		 <div class="lst" >
            
		 <ul>
            <pre>
                 <div class="prmt">
               <li>
                 <h1>Nouveautés <br><br>Promos</h1>
                
               </li>
            
            </div></pre>
             <ul>
            <div>  
                <li>
                    <h2>vanilla ice cream with chocolate</h2>
                        <img src="img/im1.png"  >
                    <h2><del id='del'>30 MAD</del> 14,99 MAD</h2>
                </li>	
                <li>
                    <h2>chocolate and hazelnut ice cream</h2>
                    <img src="img/im2.png"  >
                     <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                </li> 
            </div> 
            <div> 
                <li>
                    <h2>raspberry vanilla ice cream</h2>
                    <img src="img/im3.png"  >
                    <h2><del id='del'>50 MAD</del> 29,99 MAD</h2>
                </li> 
                
                <li>
                    <h2>strawberry ice cream</h2>
                     <img src="img/im4.png"  >
                    <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>  
                </li>
             </div>
             <div> 
                <li>
                    <h2>caramel ice cream with almonds</h2>
                    <img src="img/im5.png"  >
                    <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                       
                       
                </li>
                <li>
                    <h2>a peach ice cream</h2>
                     <img src="img/im6.png"  >
                    <h2><del id='del'>60 MAD</del> 29,99 MAD</h2>
                </li> 
             </div>
            
             <div>
                <li>
                    <h2>chocolate and mango cake</h2>
                     <img src="img/im7.png"  >
                    <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                       
                       
                </li>
                <li>
                    <h2>cocoa and hazelnut cake</h2>
                     <img src="img/im8.png"  >
                    <h2><del id='del'>60 MAD</del> 29,99 MAD</h2>
                </li>
            </div>
            <div>  <li>
                <h2>caramel ice cream with almonds</h2>
                 <img src="img/im9.png"  >
                <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                   
                   
            </li>
            <li>
                <h2>a peach ice cream</h2>
                 <img src="img/im10.png"  >
                <h2><del id='del'>60 MAD</del> 29,99 MAD</h2>
            </li> </div>
        
        <div>
         <li>
                <h2>glasse vanille</h2>
                 <img src="img/im11.jpg"  >
                <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                   
                   
            </li>
            <li>
                <h2>glasse lait-chocolat</h2>
                 <img src="img/im12.jpg"  >
                <h2><del id='del'>60 MAD</del> 29,99 MAD</h2>
            </li>
        </div>
        <div>
         <li>
                <h2>glace cacao</h2>
                 <img src="img/im13.jpg"  >
                <h2><del id='del'>40 MAD</del> 19,99 MAD</h2>
                   
                   
            </li>
            <li>
                <h2>glace fraise&vanille</h2>
                 <img src="img/im14.jpg"  >
                <h2><del id='del'>60 MAD</del> 29,99 MAD</h2>
            </li>
        </div>
		    </ul>
		       
		     
		 </div>
		</header>
		
		
   </body>



</html>
